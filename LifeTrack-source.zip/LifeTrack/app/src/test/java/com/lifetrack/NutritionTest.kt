package com.lifetrack

import com.lifetrack.data.*
import com.lifetrack.domain.*
import java.time.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class NutritionTest {
    private val today = LocalDate.of(2025, 1, 15)

    private fun time(d: LocalDate) =
        d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun food(d: LocalDate = today, meal: String = "LUNCH", kcal: Long = 620000) =
        FoodLog(
            customName = "Обед",
            mealType = meal,
            amount = 420000,
            calories = kcal,
            protein = 54000,
            fat = 16000,
            carbs = 67000,
            dateTime = time(d),
        )

    @Test
    fun parsesDecimalWithoutFloatingPointLoss() {
        assertEquals(123456L, NutritionNumber.parse("123,456"))
        assertEquals("123,456", NutritionNumber.format(123456))
        assertEquals("124", NutritionNumber.rounded(123500))
    }

    @Test
    fun rejectsNegativeAndExcessPrecision() {
        listOf("-1", "0.0001", "1000001", "nan").forEach {
            assertTrue(runCatching { NutritionNumber.parse(it) }.isFailure)
        }
        assertTrue(runCatching { NutritionNumber.parse("0", false) }.isFailure)
    }

    @Test
    fun scalesPortionAndRoundsOnce() {
        val item =
            FoodItem(
                id = 1,
                name = "Рис",
                calories = 130000,
                protein = 2700,
                fat = 300,
                carbs = 28200,
            )
        val log = FoodLogCalculator.fromItem(item, 250000, "LUNCH", time(today))
        assertEquals(325000L, log.calories)
        assertEquals(6750L, log.protein)
        assertEquals(70500L, log.carbs)
        assertEquals(1L, FoodLogCalculator.scale(1, 1, 2))
    }

    @Test
    fun itemChangesDoNotRewriteSavedPortion() {
        val item =
            FoodItem(id = 1, name = "Рис", calories = 130000, protein = 0, fat = 0, carbs = 0)
        val log = FoodLogCalculator.fromItem(item, 200000, "LUNCH", time(today))
        val changed = item.copy(calories = 200000)
        assertEquals(260000L, log.calories)
        assertEquals(
            400000L,
            FoodLogCalculator.fromItem(changed, 200000, "LUNCH", time(today)).calories,
        )
    }

    @Test
    fun sumsMealsAndMacrosForSelectedDay() {
        val s =
            NutritionSnapshot(
                logs =
                    listOf(
                        food(),
                        food(meal = "BREAKFAST", kcal = 320000),
                        food(today.minusDays(1)),
                    )
            )
        val d = NutritionCalculator.daily(s, today)
        assertEquals(940000L, d.totals.calories)
        assertEquals(108000L, d.totals.protein)
        assertEquals(2, d.logs.size)
        assertEquals(620000L, d.meals["LUNCH"]!!.calories)
        assertEquals(320000L, d.meals["BREAKFAST"]!!.calories)
    }

    @Test
    fun waterUsesSelectedDayAndEmptyDayIsZero() {
        val s =
            NutritionSnapshot(
                water =
                    listOf(
                        WaterLog(amountMl = 250, dateTime = time(today)),
                        WaterLog(amountMl = 500, dateTime = time(today)),
                        WaterLog(amountMl = 1000, dateTime = time(today.minusDays(1))),
                    )
            )
        assertEquals(750L, NutritionCalculator.daily(s, today).waterMl)
        assertEquals(0L, NutritionCalculator.daily(s, today.plusDays(1)).waterMl)
    }

    @Test
    fun periodIncludesEmptyDaysAndBoundaries() {
        val days =
            NutritionCalculator.period(
                NutritionSnapshot(logs = listOf(food())),
                today.minusDays(6),
                today,
            )
        assertEquals(7, days.size)
        assertEquals(0L, days.first().totals.calories)
        assertEquals(88571L, NutritionCalculator.average(days.map { it.totals.calories }))
        assertEquals(0L, NutritionCalculator.average(emptyList()))
    }

    @Test
    fun rejectsInvertedPeriodAndOverflow() {
        assertTrue(
            runCatching {
                    NutritionCalculator.period(NutritionSnapshot(), today, today.minusDays(1))
                }
                .isFailure
        )
        assertTrue(
            runCatching {
                    NutritionCalculator.totals(listOf(food(kcal = Long.MAX_VALUE), food(kcal = 1)))
                }
                .isFailure
        )
    }

    @Test
    fun validatesFoodBeforeSave() {
        val valid = food()
        LocalFoodRepository.validate(valid)
        listOf(
                valid.copy(amount = 0),
                valid.copy(calories = -1),
                valid.copy(customName = ""),
                valid.copy(mealType = "OTHER"),
                valid.copy(dateTime = Long.MAX_VALUE),
            )
            .forEach { assertTrue(runCatching { LocalFoodRepository.validate(it) }.isFailure) }
    }

    @Test
    fun recognitionIsExplicitlyUnavailableAndDemoIsMarked() = runBlocking {
        val image = RecognitionImage(byteArrayOf(1))
        assertTrue(
            UnconfiguredFoodRecognitionService().recognizeFood(image) is RecognitionOutcome.Offline
        )
        val result =
            DemoFoodRecognitionService().recognizeFood(image) as RecognitionOutcome.LowConfidence
        assertTrue(result.result.demonstration)
        assertEquals(
            620000L,
            NutritionCalculator.totals(result.result.items.map { it.food }).calories,
        )
        assertTrue(result.result.items.all { it.food.recognitionDemo })
        assertTrue(
            DemoFoodRecognitionService().recognizeFood(RecognitionImage(byteArrayOf()))
                is RecognitionOutcome.Error
        )
    }
}

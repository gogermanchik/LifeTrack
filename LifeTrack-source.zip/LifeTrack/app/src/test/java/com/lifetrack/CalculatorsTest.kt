package com.lifetrack

import com.lifetrack.data.*
import com.lifetrack.domain.*
import java.time.*
import org.junit.Assert.*
import org.junit.Test

class CalculatorsTest {
    private val today = LocalDate.of(2026, 10, 6)

    private fun time(d: LocalDate) =
        d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private val accounts =
        listOf(
            AccountEntity(1, "Карта", 10000),
            AccountEntity(2, "Наличные"),
            AccountEntity(3, "USD", 90000, "USD"),
        )

    private fun tx(
        id: Long,
        amount: Long,
        type: String,
        date: LocalDate = today,
        account: Long = 1,
        to: Long? = null,
    ) = TransactionEntity(id, amount, type, 1, account, to, time(date))

    @Test
    fun moneyFormattingIsIndependentOfDeviceLocale() {
        assertEquals("124 350 ₽", MoneyFormatter.format(12435000, "RUB"))
        assertEquals("1,23 €", MoneyFormatter.format(123, "EUR"))
        assertEquals("-1 $", MoneyFormatter.format(-100, "USD"))
    }

    @Test
    fun moneyUsesExactMinorUnits() {
        assertEquals(234000L, MoneyFormatter.parse("2340"))
        assertEquals(123L, MoneyFormatter.parse("1,23"))
        assertEquals("1.23", MoneyFormatter.input(123))
    }

    @Test
    fun moneyRejectsZeroNegativeAndSubcent() {
        for (v in listOf("0", "-1", "0.001", "1e30", "wrong")) assertTrue(
            runCatching { MoneyFormatter.parse(v) }.isFailure
        )
    }

    @Test
    fun percentageDoesNotOverflowLong() {
        assertEquals(100, percent(Long.MAX_VALUE, Long.MAX_VALUE))
        assertEquals(67, percent(2, 3))
        assertEquals(0, percent(1, 0))
    }

    @Test
    fun exactSumDetectsOverflow() {
        assertTrue(runCatching { sumExact(listOf(Long.MAX_VALUE, 1)) }.isFailure)
    }

    @Test
    fun transfersPreserveAggregateBalance() {
        val s =
            Snapshot(accounts = accounts, transactions = listOf(tx(1, 5000, "TRANSFER", to = 2)))
        assertEquals(5000L, FinanceCalculator.balance(s, accounts[0]))
        assertEquals(5000L, FinanceCalculator.balance(s, accounts[1]))
        val f = FinanceCalculator.stats(s, today, today, "RUB")
        assertEquals(10000L, f.balance)
        assertEquals(0L, f.income)
        assertEquals(0L, f.expense)
    }

    @Test
    fun monthsExcludeOtherCurrenciesAndPreviousMonth() {
        val s =
            Snapshot(
                accounts = accounts,
                transactions =
                    listOf(
                        tx(1, 100000, "INCOME"),
                        tx(2, 24000, "EXPENSE"),
                        tx(3, 7000, "EXPENSE", today.minusMonths(1)),
                        tx(4, 20000, "EXPENSE", account = 3),
                    ),
            )
        val f = FinanceCalculator.stats(s, today.withDayOfMonth(1), today.withDayOfMonth(31), "RUB")
        assertEquals(100000L, f.income)
        assertEquals(24000L, f.expense)
        assertEquals(76000L, f.cashFlow)
        assertEquals(76, f.savingsRate)
    }

    @Test
    fun budgetFiltersMonthCategoryAndCurrency() {
        val s =
            Snapshot(
                accounts = accounts,
                transactions =
                    listOf(
                        tx(1, 8000, "EXPENSE"),
                        tx(2, 9000, "EXPENSE", today.minusMonths(1)),
                        tx(3, 9000, "EXPENSE", account = 3),
                        tx(4, 5000, "TRANSFER", to = 2),
                    ),
            )
        assertEquals(
            8000L,
            FinanceCalculator.budgetSpent(s, BudgetEntity(month = "2026-10", amount = 10000)),
        )
        assertEquals(
            0L,
            FinanceCalculator.budgetSpent(
                s,
                BudgetEntity(month = "2026-10", amount = 10000, categoryId = 2),
            ),
        )
        assertEquals(80, percent(8000, 10000))
        assertEquals(120, percent(12000, 10000))
    }

    private fun habit(
        start: LocalDate = today.minusDays(4),
        frequency: String = "DAILY",
        days: String = "1,2,3,4,5,6,7",
    ) =
        HabitEntity(
            1,
            "Чтение",
            frequency = frequency,
            days = days,
            createdDay = start.toEpochDay(),
        )

    private fun done(vararg days: LocalDate) =
        days.map { HabitCompletionEntity(1, it.toEpochDay()) }

    @Test
    fun pendingTodayKeepsYesterdayStreak() {
        val st =
            HabitStatisticsCalculator.stats(
                habit(),
                done(today.minusDays(1), today.minusDays(2)),
                today,
            )
        assertEquals(2, st.current)
        assertEquals(2, st.best)
        assertEquals(2, st.total)
        assertEquals(40, st.rate)
    }

    @Test
    fun missedYesterdayBreaksStreak() {
        val st =
            HabitStatisticsCalculator.stats(
                habit(),
                done(today.minusDays(2), today.minusDays(3)),
                today,
            )
        assertEquals(0, st.current)
        assertEquals(2, st.best)
    }

    @Test
    fun completionTodayExtendsStreak() {
        val st =
            HabitStatisticsCalculator.stats(
                habit(),
                done(today, today.minusDays(1), today.minusDays(2)),
                today,
            )
        assertEquals(3, st.current)
        assertEquals(60, st.seven)
        assertEquals(60, st.thirty)
    }

    @Test
    fun scheduledDaysIgnoreUnscheduledDays() {
        val h = habit(today.minusDays(7), "DAYS", "2")
        val st = HabitStatisticsCalculator.stats(h, done(today, today.minusDays(7)), today)
        assertEquals(2, st.current)
        assertEquals(100, st.rate)
    }

    @Test
    fun insufficientCountDoesNotCompleteHabit() {
        val st =
            HabitStatisticsCalculator.stats(
                habit().copy(target = 2),
                listOf(HabitCompletionEntity(1, today.toEpochDay(), 1)),
                today,
            )
        assertEquals(0, st.total)
    }

    @Test
    fun futureCompletionsDoNotCount() {
        assertEquals(
            0,
            HabitStatisticsCalculator.stats(habit(), done(today.plusDays(1)), today).total,
        )
    }

    @Test
    fun weeklyTargetUsesWeeks() {
        val h = habit(today.minusDays(7), "WEEKLY").copy(weeklyTarget = 2)
        val st =
            HabitStatisticsCalculator.stats(h, done(today.minusDays(7), today.minusDays(6)), today)
        assertEquals(1, st.current)
        assertEquals(1, st.best)
    }

    @Test
    fun emptyAndFutureHabitsAreSafe() {
        assertEquals(
            0,
            HabitStatisticsCalculator.stats(habit(today.plusDays(1)), emptyList(), today).rate,
        )
        assertEquals(0, DashboardCalculator.calculate(Snapshot(), "RUB", today).due)
    }

    @Test
    fun dashboardReactsToActualRecords() {
        val s =
            Snapshot(
                accounts = accounts,
                habits = listOf(habit(), habit().copy(id = 2, archived = true)),
                completions = done(today),
                transactions =
                    listOf(tx(1, 20000, "INCOME"), tx(2, 8000, "EXPENSE", today.minusMonths(1))),
            )
        val d = DashboardCalculator.calculate(s, "RUB", today)
        assertEquals(1, d.due)
        assertEquals(1, d.done)
        assertEquals(1, d.streak)
        assertEquals(20000L, d.finance.income)
        assertEquals(8000L, d.previous.expense)
    }

    @Test
    fun leapMonthBoundaries() {
        val date = LocalDate.of(2024, 2, 29)
        val s =
            Snapshot(
                accounts = accounts,
                transactions =
                    listOf(tx(1, 123, "EXPENSE", date), tx(2, 500, "EXPENSE", date.plusDays(1))),
            )
        assertEquals(123L, FinanceCalculator.stats(s, date.withDayOfMonth(1), date, "RUB").expense)
    }

    @Test
    fun budgetThresholdsUseExactAmounts() {
        assertEquals("", BudgetCalculator.warning(7999, 10000))
        assertEquals("NEAR", BudgetCalculator.warning(8000, 10000))
        assertEquals("FULL", BudgetCalculator.warning(10000, 10000))
        assertEquals("OVER", BudgetCalculator.warning(10001, 10000))
        assertEquals("FULL", BudgetCalculator.warning(Long.MAX_VALUE, Long.MAX_VALUE))
    }

    @Test
    fun negativeCashFlowAndZeroIncome() {
        assertEquals(-500L, FinanceStats(0, 500, 0).cashFlow)
        assertEquals(0, FinanceStats(0, 500, 0).savingsRate)
    }
}

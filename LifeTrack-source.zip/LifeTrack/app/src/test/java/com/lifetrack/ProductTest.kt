package com.lifetrack

import com.lifetrack.data.*
import com.lifetrack.domain.*
import java.time.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class ProductTest {
    private fun food() =
        CatalogFood(
            "milk",
            name = "Молоко",
            baseUnit = "мл",
            calories = 60000,
            protein = 3200,
            fat = 3000,
            carbs = 4700,
            servingAmount = 250000,
        )

    @Test
    fun portionAndPieceScaleByKnownVolume() {
        val log = Portions.log(food(), 1500, "порция", "LUNCH", 1000)
        assertEquals(375000, log.amount)
        assertEquals(225000, log.calories)
        assertEquals(12000, log.protein)
    }

    @Test
    fun incompatibleUnitsAndUnknownMacrosAreRejected() {
        assertTrue(runCatching { Portions.log(food(), 100000, "г", "LUNCH", 1000) }.isFailure)
        assertTrue(
            runCatching { Portions.log(food().copy(protein = null), 100000, "мл", "LUNCH", 1000) }
                .isFailure
        )
        assertTrue(
            runCatching {
                    Portions.log(food().copy(servingAmount = null), 1000, "шт", "LUNCH", 1000)
                }
                .isFailure
        )
    }

    @Test
    fun roundingDoesNotLoseFractionalPortions() {
        assertEquals(166667, Portions.scaled(500000, 100000, 300000))
        assertTrue(runCatching { Portions.scaled(Long.MAX_VALUE, Long.MAX_VALUE) }.isFailure)
    }

    @Test
    fun mapperDistinguishesMissingFromZero() {
        val p =
            Json.parseToJsonElement(
                    """{"code":"3017620422003","product_name":"Nutella","nutriments":{"energy-kcal_100g":539,"fat_100g":30.9,"proteins_100g":0}}"""
                )
                .jsonObject
        val v = OpenFoodFactsMapper.product(p)!!
        assertEquals(539000L, v.calories)
        assertEquals(30900L, v.fat)
        assertEquals(0L, v.protein)
        assertNull(v.carbs)
    }

    @Test fun upceExpandsToValidGtin(){assertEquals("0042100005264",BarcodeValue.expandUpce("04252614"))}

    @Test
    fun barcodeChecksumAndUpcNormalization() {
        assertEquals("0049000006582", BarcodeValue.normalized("049000006582"))
        assertEquals("3017620422003", BarcodeValue.normalized("3017620422003"))
        assertTrue(runCatching { BarcodeValue.normalized("3017620422004") }.isFailure)
    }

    private fun e(source: String, kind: String, value: Long, start: Long, id: String) =
        HealthEntry(
            "$source:$id",
            source,
            externalId = id,
            kind = kind,
            start = start,
            end = start + 60000,
            value = value,
            unit = "",
        )

    @Test
    fun platformStepsHavePriorityAcrossProviders() {
        val d = LocalDate.now()
        val t = d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        assertEquals(
            6000L,
            HealthMath.daily(
                listOf(e("HC", "STEPS", 6000, t, "1"), e("GARMIN", "STEPS", 5800, t, "2")),
                "STEPS",
                d,
            ),
        )
        assertNull(HealthMath.daily(emptyList(), "STEPS", d))
    }

    @Test
    fun manualBodyValueWinsAndLatestIsUsed() {
        val d = LocalDate.now()
        val t = d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        assertEquals(
            72000L,
            HealthMath.daily(
                listOf(
                    e("HC", "WEIGHT", 73000, t, "1"),
                    e("LOCAL", "WEIGHT", 71000, t, "2"),
                    e("LOCAL", "WEIGHT", 72000, t + 100000, "3"),
                ),
                "WEIGHT",
                d,
            ),
        )
    }

    @Test
    fun duplicateWorkoutsAreNotAddedTwice() {
        val t = System.currentTimeMillis()
        assertEquals(
            1,
            HealthMath.workouts(
                    listOf(
                        e("HC", "WORKOUT", 30, t, "1"),
                        e("GARMIN", "WORKOUT", 30, t + 1000, "2"),
                    )
                )
                .size,
        )
    }

    @Test
    fun recoveryNeedsHistoryAndExplainsInputs() {
        val d = LocalDate.now()
        fun time(date: LocalDate): Long {
            return date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }
        val rows = (0L..7L).map { e("HC", "RESTING_HR", 60000, time(d.minusDays(it)), "$it") }
        assertNull(HealthMath.recovery(rows, d))
        val sufficient = rows + e("HC", "SLEEP", 8 * 3600000L, time(d), "sleep")
        assertEquals(100, HealthMath.recovery(sufficient, d)!!.score)
        assertTrue(HealthMath.recovery(sufficient, d)!!.explanation.contains("7 дней"))
    }

    @Test
    fun correlationsRequireEnoughPairedAndVaryingDays() {
        assertNull(HealthMath.correlation((1..13).map { it.toDouble() to it.toDouble() }))
        assertNull(HealthMath.correlation((1..14).map { 1.0 to it.toDouble() }))
        assertEquals(
            1.0,
            HealthMath.correlation((1..14).map { it.toDouble() to 2.0 * it })!!,
            0.0001,
        )
    }

    @Test
    fun recipePreservesIngredientTotals() {
        val r = Recipe(1, "Суп", 4)
        val ingredients =
            listOf(
                RecipeIngredient(
                    recipeId = 1,
                    name = "Овощи",
                    amount = 500000,
                    unit = "г",
                    calories = 200000,
                    protein = 10000,
                    fat = 1000,
                    carbs = 35000,
                )
            )
        val log = Portions.recipe(r, ingredients, 1500, "DINNER", 1000)
        assertEquals(75000L, log.calories)
        assertEquals(3750L, log.protein)
        assertTrue(log.composition.contains("Овощи"))
    }

    @Test
    fun garminMapperRejectsWrongSourceAndIntervals() {
        val t = System.currentTimeMillis()
        val a = e("GARMIN", "STEPS", 100, t, "1")
        assertEquals("GARMIN:STEPS:1", GarminMapper.map(a).id)
        assertTrue(runCatching { GarminMapper.map(a.copy(source = "HC")) }.isFailure)
        assertTrue(runCatching { GarminMapper.map(a.copy(end = t - 1)) }.isFailure)
    }

    @Test
    fun receiptCandidateIsEditableAndDoesNotInferCurrency() {
        val v = ReceiptTextMapper.parse("Shop\nTOTAL 1 234,56\nThanks")
        assertEquals(123456L, v.amountMinor)
        assertNull(v.currency)
        assertEquals("LOW", v.confidence)
    }
}

package com.lifetrack

import com.lifetrack.domain.LabelNutritionMapper
import org.junit.Assert.*
import org.junit.Test

class LabelNutritionTest {
    @Test
    fun explicitlyPer100gIsParsedWithoutConfusingSaltOrSugar() {
        val p =
            LabelNutritionMapper.parse(
                "Nutrition per 100 g\nEnergy 840 kJ / 200 kcal\nFat 10.5 g\nof which saturates 2 g\nCarbohydrate 20 g\nof which sugars 4 g\nProtein 7 g\nSalt 0.5 g"
            )
        assertEquals(200000L, p.calories)
        assertEquals(10500L, p.fat)
        assertEquals(20000L, p.carbs)
        assertEquals(7000L, p.protein)
        assertEquals(100, p.basis)
    }

    @Test
    fun missingValuesAndServingBasisAreNeverInvented() {
        val p = LabelNutritionMapper.parse("Per serving 30 g\nFat 2 g\nEnergy 120 kJ")
        assertNull(p.basis)
        assertNull(p.calories)
        assertNull(p.protein)
        assertNull(p.carbs)
        assertEquals(2000L, p.fat)
    }

    @Test
    fun liquidBasisKeepsMillilitres() {
        val p = LabelNutritionMapper.parse("Per 100 ml\nProtein 3 g\nEnergy 60 kcal")
        assertEquals("мл", p.unit)
    }

    @Test
    fun multipleColumnsRequireManualReview() {
        val p =
            LabelNutritionMapper.parse(
                "Per serving / Per 100 g\nProtein 2 g / 8 g\nEnergy 50 kcal / 200 kcal"
            )
        assertNull(p.protein)
        assertNull(p.calories)
    }
}

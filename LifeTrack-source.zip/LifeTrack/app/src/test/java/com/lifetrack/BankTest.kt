package com.lifetrack

import com.lifetrack.banking.*
import com.lifetrack.data.*
import com.lifetrack.domain.*
import java.time.LocalDate
import org.junit.Assert.*
import org.junit.Test

class BankTest {
    private val parser = BankParserRegistry()

    private fun parse(text: String) =
        parser.parse(setOf("selected"), "selected", "Банк", text, 1000)

    @Test
    fun onlySelectedPackagesCanBeParsed() {
        assertNull(parser.parse(setOf("selected"), "other", "Банк", "Покупка 120 ₽ Магазин", 1000))
    }

    @Test
    fun decimalAmountsAndBalanceAreNotConfused() {
        val p = parse("Покупка 1 234,56 ₽ ВкусВилл. Баланс 8 000 ₽")!!
        assertEquals(123456L, p.amount)
        assertEquals("ВкусВилл", p.rawMerchant)
        assertEquals(Confidence.LOW, p.confidence)
    }

    @Test
    fun otpAndAdsAreIgnored() {
        assertNull(parse("Код подтверждения покупки 1234. Покупка 500 ₽"))
        assertNull(parse("Кредит одобрен. Оплата 500 ₽"))
        assertNull(parse("Привет! Новая акция 500 ₽"))
    }

    @Test
    fun genericNeverAutomaticallyClaimsHighConfidence() {
        assertEquals(Confidence.MEDIUM, parse("Покупка 99.90 USD Cafe")!!.confidence)
        assertEquals(BankKind.REFUND, parse("Возврат 100 ₽ Магазин")!!.type)
        assertEquals(BankKind.TRANSFER, parse("Перевод 100 ₽ Друг")!!.type)
    }

    @Test
    fun likelyDuplicatesStillPreserveDifferentIdentities() {
        val p = parse("Покупка 100 ₽ ООО «ВкусВилл»")!!
        assertEquals("вкусвилл", p.normalizedMerchant)
        assertTrue(BankFingerprint.likelySame(p, p.copy(timestamp = 61000)))
        assertFalse(BankFingerprint.likelySame(p, p.copy(amount = 10100)))
        assertNotEquals(
            BankFingerprint.hash("notification1"),
            BankFingerprint.hash("notification2"),
        )
    }

    @Test
    fun csvSupportsQuotedDescriptionsAndExactMinorUnits() {
        val t =
            CsvStatementReader.read(
                "Дата;Сумма;Валюта;Магазин;Описание\n05.10.2026;-1234,56;RUB;Кафе;\"Обед; с другом\"\n05.10.2026;400;RUB;Кафе;Возврат\n"
                    .toByteArray()
            )
        assertEquals("Обед; с другом", t.rows[0][4])
        val rows = StatementMapping.preview(t, StatementMapping.detect(t.headers), "RUB")
        assertEquals(123456L, rows[0].parsed!!.amount)
        assertEquals(BankKind.PURCHASE, rows[0].parsed!!.type)
        assertEquals(BankKind.REFUND, rows[1].parsed!!.type)
    }

    @Test
    fun explicitExpenseTypeOverridesPositiveMagnitude() {
        val t=CsvStatementReader.read("Дата;Сумма;Тип;Магазин\n05.10.2026;500;Расход;Кафе\n".toByteArray())
        assertEquals(BankKind.PURCHASE,StatementMapping.preview(t,StatementMapping.detect(t.headers),"RUB").single().parsed!!.type)
    }
    @Test
    fun invalidCsvAndSubcentAreRejected() {
        assertTrue(
            runCatching { CsvStatementReader.read("Дата;Сумма\n\"broken".toByteArray()) }.isFailure
        )
        val t = CsvStatementReader.read("Дата;Сумма\n05.10.2026;0,001\n".toByteArray())
        assertNull(
            StatementMapping.preview(t, StatementMapping.detect(t.headers), "RUB").single().parsed
        )
    }

    @Test
    fun refundReducesExpenseAndBudgetWithoutInflatingIncome() {
        val a = AccountEntity(1, "Карта", 100000)
        val now = System.currentTimeMillis()
        val s =
            Snapshot(
                accounts = listOf(a),
                transactions =
                    listOf(
                        TransactionEntity(1, 10000, "EXPENSE", 1, 1, null, now),
                        TransactionEntity(2, 3000, "REFUND", 1, 1, null, now),
                    ),
            )
        val today = LocalDate.now()
        val f = FinanceCalculator.stats(s, today, today, "RUB")
        assertEquals(0L, f.income)
        assertEquals(7000L, f.expense)
        assertEquals(93000L, f.balance)
        assertEquals(
            7000L,
            FinanceCalculator.budgetSpent(
                s,
                BudgetEntity(month = java.time.YearMonth.now().toString(), amount = 20000),
            ),
        )
    }

    @Test
    fun creditRepaymentDoesNotBecomeSecondExpense() {
        val accounts =
            listOf(
                AccountEntity(1, "Карта", 200000),
                AccountEntity(2, "Кредит", -100000, kind = "CREDIT"),
            )
        val s =
            Snapshot(
                accounts = accounts,
                transactions =
                    listOf(
                        TransactionEntity(
                            1,
                            50000,
                            "TRANSFER",
                            null,
                            1,
                            2,
                            System.currentTimeMillis(),
                        )
                    ),
            )
        assertEquals(-50000L, FinanceCalculator.balance(s, accounts[1]))
        assertEquals(
            100000L,
            FinanceCalculator.stats(s, LocalDate.now(), LocalDate.now(), "RUB").balance,
        )
        assertEquals(
            0L,
            FinanceCalculator.stats(s, LocalDate.now(), LocalDate.now(), "RUB").expense,
        )
    }
}

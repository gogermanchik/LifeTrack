/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.outlined

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Outlined.AccountBalanceWallet: ImageVector
    get() {
        if (_accountBalanceWallet != null) {
            return _accountBalanceWallet!!
        }
        _accountBalanceWallet =
            materialIcon(name = "Outlined.AccountBalanceWallet") {
                materialPath {
                    moveTo(21.0f, 7.28f)
                    verticalLineTo(5.0f)
                    curveToRelative(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f)
                    horizontalLineTo(5.0f)
                    curveToRelative(-1.11f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    verticalLineToRelative(14.0f)
                    curveToRelative(0.0f, 1.1f, 0.89f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(14.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineToRelative(-2.28f)
                    curveToRelative(0.59f, -0.35f, 1.0f, -0.98f, 1.0f, -1.72f)
                    verticalLineTo(9.0f)
                    curveToRelative(0.0f, -0.74f, -0.41f, -1.37f, -1.0f, -1.72f)
                    close()
                    moveTo(20.0f, 9.0f)
                    verticalLineToRelative(6.0f)
                    horizontalLineToRelative(-7.0f)
                    verticalLineTo(9.0f)
                    horizontalLineToRelative(7.0f)
                    close()
                    moveTo(5.0f, 19.0f)
                    verticalLineTo(5.0f)
                    horizontalLineToRelative(14.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(-6.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    verticalLineToRelative(6.0f)
                    curveToRelative(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(6.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineTo(5.0f)
                    close()
                }
                materialPath {
                    moveTo(16.0f, 12.0f)
                    moveToRelative(-1.5f, 0.0f)
                    arcToRelative(1.5f, 1.5f, 0.0f, true, true, 3.0f, 0.0f)
                    arcToRelative(1.5f, 1.5f, 0.0f, true, true, -3.0f, 0.0f)
                }
            }
        return _accountBalanceWallet!!
    }

private var _accountBalanceWallet: ImageVector? = null

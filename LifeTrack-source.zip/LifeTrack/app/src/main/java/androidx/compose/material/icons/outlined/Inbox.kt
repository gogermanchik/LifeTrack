/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.outlined

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Outlined.Inbox: ImageVector
    get() {
        if (_inbox != null) {
            return _inbox!!
        }
        _inbox =
            materialIcon(name = "Outlined.Inbox") {
                materialPath {
                    moveTo(19.0f, 3.0f)
                    lineTo(5.0f, 3.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    verticalLineToRelative(14.0f)
                    curveToRelative(0.0f, 1.1f, 0.89f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(14.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    lineTo(21.0f, 5.0f)
                    curveToRelative(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f)
                    close()
                    moveTo(19.0f, 19.0f)
                    lineTo(5.0f, 19.0f)
                    verticalLineToRelative(-3.0f)
                    horizontalLineToRelative(3.56f)
                    curveToRelative(0.69f, 1.19f, 1.97f, 2.0f, 3.45f, 2.0f)
                    reflectiveCurveToRelative(2.75f, -0.81f, 3.45f, -2.0f)
                    lineTo(19.0f, 16.0f)
                    verticalLineToRelative(3.0f)
                    close()
                    moveTo(19.0f, 14.0f)
                    horizontalLineToRelative(-4.99f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    lineTo(5.0f, 14.0f)
                    lineTo(5.0f, 5.0f)
                    horizontalLineToRelative(14.0f)
                    verticalLineToRelative(9.0f)
                    close()
                }
            }
        return _inbox!!
    }

private var _inbox: ImageVector? = null

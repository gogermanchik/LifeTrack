package com.lifetrack.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.lifetrack.data.*
import com.lifetrack.domain.*
import java.io.File
import java.time.LocalDate
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

sealed interface PhotoUiState {
    data object Idle : PhotoUiState

    data object Preparing : PhotoUiState

    data class Preview(val file: File) : PhotoUiState

    data class Loading(val file: File) : PhotoUiState

    data class Result(
        val file: File,
        val result: FoodRecognitionResult,
        val lowConfidence: Boolean,
    ) : PhotoUiState

    data class Offline(val file: File, val message: String) : PhotoUiState

    data class Error(val file: File?, val message: String) : PhotoUiState
}

class NutritionViewModel(app: Application) : AndroidViewModel(app) {
    private val db =
        LifeStore.get(app)
    val repository = LocalFoodRepository(db)
    val data =
        repository.snapshots.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            NutritionSnapshot(),
        )
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 5)
    val date = MutableStateFlow(LocalDate.now())
    val photo = MutableStateFlow<PhotoUiState>(PhotoUiState.Idle)
    var cameraFile: File? = null
        private set

    private val recognition: FoodRecognitionService = BackendFoodRecognitionService(app)
    private var photoJob: Job? = null

    init {
        launch { repository.initialize() }
    }

    fun launch(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                messages.emit(e.message ?: "Не удалось сохранить данные")
            }
        }
    }

    fun cameraUri(): Uri {
        val f =
            File.createTempFile(
                "camera-",
                ".jpg",
                File(getApplication<Application>().cacheDir, "food_photos").apply { mkdirs() },
            )
        cameraFile = f
        return androidx.core.content.FileProvider.getUriForFile(
            getApplication(),
            "com.lifetrack.photos",
            f,
        )
    }

    fun selectPhoto(uri: Uri) {
        photoJob?.cancel()
        currentFile()?.delete()
        photoJob =
            viewModelScope.launch {
                photo.value = PhotoUiState.Preparing
                try {
                    val file =
                        withContext(Dispatchers.IO) {
                            FoodPhotoProcessor.prepare(getApplication(), uri)
                        }
                    cameraFile?.delete()
                    photo.value = PhotoUiState.Preview(file)
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    photo.value =
                        PhotoUiState.Error(
                            null,
                            "Не удалось открыть фото. Выберите другое изображение.",
                        )
                }
            }
    }

    fun resetPhoto() {
        photoJob?.cancel()
        val file = currentFile()
        file?.delete()
        cameraFile?.delete()
        photo.value = PhotoUiState.Idle
    }

    fun currentFile(): File? =
        when (val p = photo.value) {
            is PhotoUiState.Preview -> p.file
            is PhotoUiState.Loading -> p.file
            is PhotoUiState.Result -> p.file
            is PhotoUiState.Offline -> p.file
            is PhotoUiState.Error -> p.file
            else -> null
        }

    fun recognize(demo: Boolean = false) {
        val file = currentFile() ?: return
        photoJob?.cancel()
        photoJob =
            viewModelScope.launch {
                photo.value = PhotoUiState.Loading(file)
                try {
                    val service = recognition
                    val bytes = withContext(Dispatchers.IO) { file.readBytes() }
                    val result = service.recognizeFood(RecognitionImage(bytes))
                    photo.value =
                        when (result) {
                            is RecognitionOutcome.Success ->
                                PhotoUiState.Result(file, result.result, false)
                            is RecognitionOutcome.LowConfidence ->
                                PhotoUiState.Result(file, result.result, true)
                            is RecognitionOutcome.Error -> PhotoUiState.Error(file, result.message)
                            is RecognitionOutcome.Offline ->
                                PhotoUiState.Offline(file, result.message)
                        }
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    photo.value =
                        PhotoUiState.Error(
                            file,
                            "Не удалось выполнить анализ. Попробуйте снова или заполните вручную.",
                        )
                }
            }
    }

    fun editRecognition(index: Int, log: FoodLog) {
        val result = photo.value as? PhotoUiState.Result ?: return
        photo.value =
            result.copy(
                result =
                    result.result.copy(
                        items =
                            result.result.items.mapIndexed { i, item ->
                                if (i == index) item.copy(food = log) else item
                            }
                    )
            )
    }

    fun removeRecognition(index: Int) {
        val result = photo.value as? PhotoUiState.Result ?: return
        photo.value =
            result.copy(
                result =
                    result.result.copy(
                        items = result.result.items.filterIndexed { i, _ -> i != index }
                    )
            )
    }

    fun saveRecognition(meal: String, onFinished: () -> Unit, onDone: () -> Unit) {
        val p = photo.value as? PhotoUiState.Result ?: return
        launch {
            try {
                require(p.result.items.isNotEmpty())
                val time =
                    date.value
                        .atStartOfDay(java.time.ZoneId.systemDefault())
                        .toInstant()
                        .toEpochMilli()
                repository.saveAll(
                    p.result.items.map { it.food.copy(mealType = meal, dateTime = time) }
                )
                messages.emit("Добавлено в дневник")
                resetPhoto()
                onDone()
            } finally {
                onFinished()
            }
        }
    }

    private var savingFood = false

    fun save(log: FoodLog, onDone: () -> Unit) {
        if (savingFood) return
        savingFood = true
        launch {
            try {
                repository.save(log)
                messages.emit(if (log.id == 0L) "Еда добавлена" else "Запись обновлена")
                onDone()
            } finally {
                savingFood = false
            }
        }
    }

    fun delete(log: FoodLog) = launch {
        repository.delete(log)
        messages.emit("Запись удалена")
    }

    fun addWater(amount: Long) = launch {
        repository.water(
            WaterLog(
                amountMl = amount,
                dateTime =
                    date.value
                        .atStartOfDay(java.time.ZoneId.systemDefault())
                        .toInstant()
                        .toEpochMilli(),
            )
        )
        messages.emit("Вода добавлена")
    }

    fun deleteWater(log: WaterLog) = launch { repository.deleteWater(log) }

    override fun onCleared() {
        db.close()
        super.onCleared()
    }
}

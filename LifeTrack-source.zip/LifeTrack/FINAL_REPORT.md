# LifeTrack 1.4 — фактический отчёт

Обновлён существующий Android-проект. Подготовлен установочный debug APK; это не подписанный релиз Google Play. Большой master prompt выполнен частично: основной локальный продукт и интеграционные потоки реализованы, внешние сервисы и часть P1/P2 остаются открытыми. PASS ниже относится только к явно описанной проверке. PARTIAL/NOT_VERIFIED добавлены, чтобы не выдавать ограниченную проверку за полный PASS.

## Сборка и данные

| Поле | Статус | Фактическое подтверждение |
|---|---|---|
| BUILD | PASS | `test assembleDebug assembleDebugAndroidTest lintDebug`, APK 1.4.0 / versionCode 5, minSdk 26, targetSdk 36 |
| TESTS | PASS | 58 unit tests в Debug и 58 в Release; 25 Android instrumentation tests на API 35; 6 backend tests. Lint: 0 errors, 30 warnings |
| ROOM MIGRATIONS | PASS | Явные миграции 1→2→3→4, без destructive fallback; миграционные тесты и обновление существующей v2 базы |
| DATA PRESERVED | PASS | Все исходные значения всех 11 таблиц совпали после v2→v4. Проверка на сохранённой базе эмулятора, не на личном телефоне пользователя |
| DESIGN SYSTEM | PASS | Свои Compose-компоненты, Manrope, зелёный accent, warm off-white и charcoal, пять разделов, единый бренд LifeBrand |
| TODAY | PASS | Нативный экран с реальными локальными итогами питания, привычек, денег и целей |
| NUTRITION | PASS | Дневник, БЖУ, порции, вода, добавление/удаление, копирование дня; native save/reopen проверен |
| BARCODE | PASS | CameraX + ML Kit, EAN/UPC, ручной ввод/фото/фонарик; распознавание fixture и реальный lookup 3017620422003, сохранение 15 г Nutella |
| FOOD SEARCH | PASS | Реальный Open Food Facts запрос Nutella и нативный поиск; локальный кэш при недоступности сети |
| FOOD DATABASE | PASS | Каталог, избранное, недавние, локальные исправления; неизвестные БЖУ остаются неизвестными |
| PHOTO RECOGNITION | REQUIRES_CREDENTIAL | Android consent/upload/review/save и backend Responses vision подготовлены. Без ключа сервер возвращает явную ошибку, без подставных блюд. Реальный vision E2E не проверен |
| LABEL OCR | PARTIAL | Локальная ML Kit OCR и реальное чтение латинского fixture проверены; исправляемая форма. Кириллица и дополнительные поля клетчатки/сахара не реализованы |
| RECIPES | PARTIAL | Рецепты с ингредиентами и точным расчётом, проверены расчёты/Room; полный нативный пользовательский цикл не проверен |
| WATER | PASS | Существующий журнал сохранён, локальные записи и расчёт проверены |
| CAFFEINE | PARTIAL | Ручной журнал известных мг, без угадывания состава кофе; автоматическая связь с продуктами не реализована |
| HEALTH CONNECT | PASS (ограниченный E2E) | Системный consent и 5 read permissions на API 35; реальный SDK read/instrumentation. Пустая база не превращается в фиктивные измерения: агрегаты без data origin отбрасываются |
| SAMSUNG HEALTH PATH | NOT_AVAILABLE / NOT_VERIFIED | Путь через Health Connect реализован; Samsung Health и реальные записи устройства на тестовом эмуляторе отсутствуют |
| GARMIN CONNECT | REQUIRES_EXTERNAL_APPROVAL | Backend OAuth2 PKCE, хранение/refresh токенов, normalized importer подготовлены. Нет партнёрского approval и официальных private DTO/webhook контрактов |
| HEALTH DEDUPLICATION | PASS | Unit tests приоритета источников, daily aggregate и повторных тренировок; реальные пересечения Samsung/Garmin не проверены |
| SLEEP | PARTIAL | Реальные Health Connect sessions/stages и история, прозрачный empty state; физические записи сна не проверены |
| ACTIVITY | PARTIAL | Чтение steps/distance/calories; API и consent проверены, физическая история отсутствует |
| WORKOUTS | PARTIAL | Импорт/история/дедупликация реализованы, проверены правила; физический E2E отсутствует |
| BODY | PARTIAL | Ручной вес и Health Connect weight/height/body fat, история; полный device flow не проверен |
| RECOVERY | PARTIAL | Прозрачная формула: 70% сон относительно 8 часов, 30% resting HR относительно личной истории ≥7 дней. Нет данных — нет оценки. Не медицинская оценка |
| HABITS | PASS | Существующие привычки/отметки/серии сохранены, нативный экран проверен |
| AUTO HABITS | PASS | Шаги/сон/вода/тренировки, реактивное и background обновление, ручное снятие имеет приоритет; instrumentation покрывает обновление |
| FINANCE | PASS | Счета, расходы/доходы/переводы/возвраты, existing logic сохранена; native statement→transactions и cash→transfer проверены |
| BANK NOTIFICATIONS | PARTIAL / NOT_VERIFIED | Opt-in NotificationListenerService, allowlist, локальный generic parser, очередь и dedup. Реальный банк E2E не проверен. Нет bank-specific HIGH parsers: неизвестные форматы не сохраняются автоматически |
| FINANCE INBOX | PASS | Нативное редактирование/подтверждение, снятие наличных подтверждено переводом в наличный счёт; очередь стала пустой, restart persistence проверен |
| STATEMENT IMPORT | PASS | CSV UTF-8/cp1251 и XLSX, mapping/preview/confirm/profile. Native CSV picker→preview→import проверен; XLSX fixture instrumentation. XLS/формулы не поддержаны |
| BANK RECONCILIATION | PASS (repository tests) | Однозначное совпадение выписки с provisional записью; неоднозначное требует проверки. Реальное bank notification + statement E2E не проверено |
| MERCHANT LEARNING | PASS (repository tests) | Правила создаются только с явным согласием; category update и сохранение проверены |
| BUDGETS | PARTIAL | Существующие бюджеты сохранены, возвраты уменьшают расход; проверки расчётов, native full-cycle QA не проведён |
| SUBSCRIPTIONS | PARTIAL | Ручной журнал и прогноз регулярных платежей; автоматическое обнаружение не реализовано |
| CREDIT/DEBT | PARTIAL | Отрицательный баланс долга и погашение own-account transfer; APR/лимиты/график погашения отсутствуют |
| NET WORTH | NOT_IMPLEMENTED | Расширенная модель активов/обязательств и cash-flow forecast отложены |
| GOALS | PARTIAL | Существующие цели, связь с savings/weight/workouts/habits; расчёты проверены, полный native cycle не проверен |
| ANALYTICS | PARTIAL | Периоды/источники и локальные графики реализованы; часть cross-domain аналитики не завершена. Пропуски не подставлены нулями, график может сжимать отсутствующие дни |
| WEEKLY REVIEW | PARTIAL | Локальный обзор с реальными итогами, без генеративных выдуманных рекомендаций; full native QA не проведён |
| ASSISTANT | NOT_IMPLEMENTED | Assistant/NL search отложены |
| WIDGETS | NOT_VERIFIED | RemoteViews Today, реальные локальные показатели и deep actions реализованы; launcher-host E2E не подтверждён |
| BACKUP | PASS (database scope) | JSON backup v1–v4, валидация и атомарное восстановление DB/settings проверены. Не переносит фото/cache assets; encrypted archive/app lock отсутствуют |
| PRIVACY | PARTIAL | Банки локально, без raw notification persistence/логинов/OTP/accessibility; токены Android Keystore, ключ vision только на сервере, photo consent. Нужны опубликованная политика и Play/Health Connect declarations перед релизом |

## Реальные провайдеры

FOOD PROVIDERS: Open Food Facts (HTTP), локальный каталог пользователя. Никакого платного food API не зарегистрировано.

HEALTH PROVIDERS: Android Health Connect. Samsung через Health Connect — подготовлен путь. Garmin — подготовлен backend, не подключён.

VISION PROVIDER: OpenAI Responses API, server-side, default model `gpt-4o-mini`; REQUIRES_CREDENTIAL. Реальный запрос с ключом не выполнялся.

GARMIN: REQUIRES_EXTERNAL_APPROVAL. Trusted normalized import готов; официальный partner webhook parsing/verification не выдуман.

BANK API: не используется. Уведомления разрешённых приложений и импорт выписки обрабатываются локально. Неизвестные банки работают через подтверждение пользователем.

APK: `outputs/LifeTrack.apk` — установочная debug сборка. SHA-256 рядом. Исходники: `LifeTrack-source.zip`; backend: `LifeTrack-backend.zip`.

## Внешние требования

1. Email владельца и выбранный hosting для регистрации и публичного HTTPS backend. Регистрации не выполнены: этих данных нет.
2. Server-side OpenAI API key и billing. Секреты не отправлять в чат; задаются на сервере.
3. Garmin Developer Program approval, OAuth credentials и официальные partner contracts.
4. Физический телефон с выбранными банками и Samsung Health для реального notification/health E2E.
5. Собственный release signing key, политика приватности и декларации Google Play/Health Connect для публикации.

## Остаток

Не завершены receipt OCR, assistant, NL search, mood/energy, расширенный net worth/cash-flow, Quick Settings/Wear OS/advanced widgets, bank-specific HIGH parsers, автоматическое обнаружение подписок, кредитные APR/лимиты/графики, OCR кириллицы и перенос photo assets в backup. Backend не опубликован, платные аккаунты не созданы. Эти пункты не выдаются за готовые интеграции.

Нативные скриншоты — реальные экраны эмулятора с явно подготовленной QA/демо базой; данные не встроены в новый APK и не создаются автоматически у нового пользователя. Исходная база эмулятора восстановлена после QA. На физическом телефоне пользователя установка/сброс не выполнялись.

Логи и машинные доказательства: `verification/product/`, проверка сохранности — `verification/product-data-preserved.json`.

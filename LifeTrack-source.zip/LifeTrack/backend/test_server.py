import importlib.util, json, os, tempfile, threading, unittest
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from pathlib import Path
class GatewayTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory();os.environ['LIFETRACK_DB']=str(Path(cls.temp.name)/'test.sqlite')
  spec=importlib.util.spec_from_file_location('gateway',Path(__file__).with_name('server.py'));cls.api=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.api);cls.api.init()
  cls.server=cls.api.ThreadingHTTPServer(('127.0.0.1',0),cls.api.Handler);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls): cls.server.shutdown();cls.server.server_close();cls.temp.cleanup()
 def request(self,path,value=None,token=None):
  headers={'Content-Type':'application/json'}
  if token:headers['Authorization']='Bearer '+token
  req=Request(self.base+path,data=json.dumps(value).encode() if value is not None else None,headers=headers)
  try:
   with urlopen(req) as r:return r.status,json.load(r)
  except HTTPError as e:return e.code,json.load(e)
 def paired(self):
  status,pair=self.request('/pair/start',{});self.assertEqual(200,status)
  status,v=self.request('/pair/poll',{'deviceCode':pair['deviceCode']});self.assertTrue(v['pending'])
  with self.api.connect() as c:c.execute('UPDATE pairs SET approved=1 WHERE user_code=?',(pair['userCode'],))
  status,v=self.request('/pair/poll',{'deviceCode':pair['deviceCode']});self.assertEqual(200,status);return v['token'],pair
 def test_pairing_requires_approval_is_single_use_and_revocable(self):
  token,pair=self.paired();self.assertEqual(410,self.request('/pair/poll',{'deviceCode':pair['deviceCode']})[0]);self.assertEqual(200,self.request('/config',token=token)[0]);self.assertEqual(200,self.request('/session/revoke',{},token)[0]);self.assertEqual(401,self.request('/config',token=token)[0])
 def test_no_key_reports_requirement_and_never_demo(self):
  token,_=self.paired();previous=self.api.VISION_KEY;self.api.VISION_KEY=''
  try:
   status,v=self.request('/recognize',{'image':'invalid'},token);self.assertEqual(503,status);self.assertNotIn('items',v)
  finally:self.api.VISION_KEY=previous
 def test_unknown_auth_and_invalid_request_are_rejected(self):
  self.assertEqual(401,self.request('/config',token='invalid')[0]);self.assertEqual(410,self.request('/pair/poll',{'deviceCode':'invalid'})[0])
 def test_vision_contract_rejects_unknown_or_negative_values(self):
  good={'items':[{'name':'Яблоко','grams':150000,'calories':75000,'protein':300,'fat':100,'carbs':17000,'confidence':'MEDIUM'}],'uncertain':True};self.assertEqual(good,self.api.validate_items(good));good['items'][0]['grams']=-1
  with self.assertRaises(self.api.ApiError):self.api.validate_items(good)
 def test_garmin_cannot_authorize_before_approval(self):
  token,_=self.paired();self.assertEqual(503,self.request('/garmin/start',{},token)[0])
 def test_garmin_state_and_contract_validation(self):
  with self.assertRaises(self.api.ApiError):self.api.GarminAuthManager.exchange('fake','wrong')
  with self.assertRaises(self.api.ApiError):self.api.GarminMapper.validate({'source':'GARMIN','value':-1})
if __name__=='__main__':unittest.main()

# LifeTrack gateway

Deploy Dockerfile behind HTTPS on a provider with persistent /data volume (SQLite). Set server environment from .env.example. No deployment or paid resource is created by this repository. PUBLIC_URL must be your real HTTPS address. Allow outbound api.openai.com. Reverse proxy: request body cap 2.8 MB, timeout 70 s, redact Authorization/query codes, rate limit pairing per actual client IP; do not expose port 8080 directly to the Internet. Verify dependency vulnerabilities and TLS configuration before public release.

In Android: Ещё → Подключения → HTTPS address → Подключить устройство. Approve the displayed code in your own server console:
`python server.py approve AABBCCDD`
Polling retrieves a randomly generated bearer, stored encrypted with Android Keystore in noBackup. Server stores only SHA256 of it, expires after 90 days; reconnect when expired. Revoking removes session and Garmin consent if linked. Device registration has no implicit success and needs explicit owner approval.

Photo: OPENAI_API_KEY + vision-capable VISION_MODEL. Server validates/re-encodes JPEG, strips metadata, uses Responses API structured output and store=false, validates numeric bounds. No photos are persisted or logged. Third-party provider retention remains governed by its own API policy; store=false is not a claim of zero retention. Approximate ingredients require user review and explicit diary save. No key: HTTP 503, never demo. Test live analysis after obtaining a key; NOT_VERIFIED now.

Garmin: apply to Garmin Connect Developer Program, obtain approved app ID/secret and registered HTTPS callback PUBLIC_URL/garmin/callback; set GARMIN_APPROVED=true and TOKEN_ENCRYPTION_KEY (Fernet). OAuth2 PKCE + state, token exchange, rotating refresh, encrypted tokens and deregistration follow Garmin's public specification. Vendor health export payload contracts and PUSH/PING verification are available to approved partners: adapt those documented DTOs to the normalized HealthEntry contract and call GarminSyncManager.ingest. Public unverified webhooks are intentionally absent. The current normalized importer is complete, but vendor DTO ingestion is REQUIRES_EXTERNAL_APPROVAL. Never claim a complete Garmin production sync from this pre-approval adapter.

Official references:
- https://developers.openai.com/api/docs/guides/images-vision
- https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses
- https://developerportal.garmin.com/sites/default/files/OAuth2PKCE.pdf
- https://developer.garmin.com/gc-developer-program/

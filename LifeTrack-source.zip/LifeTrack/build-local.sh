#!/bin/sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TOOLCHAIN_DIR=${LIFETRACK_TOOLCHAIN:-"$PROJECT_DIR/../../work/toolchain"}
if [ -z "${JAVA_HOME:-}" ] && [ -d "$TOOLCHAIN_DIR" ]; then
    LOCAL_JDK=$(find "$TOOLCHAIN_DIR" -type d -path '*/Contents/Home' -print -quit)
    if [ -n "$LOCAL_JDK" ]; then export JAVA_HOME="$LOCAL_JDK"; fi
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$TOOLCHAIN_DIR/android" ]; then
    export ANDROID_HOME="$TOOLCHAIN_DIR/android"
fi
if [ -d "$TOOLCHAIN_DIR/gradle-home" ]; then
    export GRADLE_USER_HOME="$TOOLCHAIN_DIR/gradle-home"
fi
cd "$PROJECT_DIR"
if [ "$#" -eq 0 ]; then set -- test assembleDebug; fi
exec ./gradlew "$@"

# LifeTrack 1.4

Питание, привычки, финансы и личный прогресс в одном Android-приложении. Обновлён существующий проект; Room v4 с явными миграциями, Compose design system, локальная работа без обязательной регистрации.

Фактические возможности и ограничения: [FINAL_REPORT.md](FINAL_REPORT.md), [RELEASE_1.4.md](RELEASE_1.4.md), [BANK_AUTOMATION.md](BANK_AUTOMATION.md). Vision/Garmin не подключены без внешних credentials/approval. Open Food Facts использует сеть; остальные локальные журналы доступны без неё. Health Connect требует системного согласия, банковские уведомления — отдельного opt-in.

## Сборка

Нужны JDK 17 и Android SDK platform 36. Задайте `ANDROID_HOME` или `sdk.dir` в локальном `local.properties`, затем:

```sh
./gradlew test assembleDebug assembleDebugAndroidTest lintDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. Минимальная версия Android 8.0 / API 26, target 36. Для Google Play нужны собственный release signing key и декларации приватности/Health Connect. Готовый APK в соседнем `LifeTrack.apk` подписан debug key.

Локальный helper `build-local.sh` использует toolchain из соседней рабочей папки; toolchain не входит в архив. При переносе используйте собственные JDK/SDK. Wrapper входит в проект.

## Проверки

Финальная версия: 58 unit tests Debug + 58 Release, 25 instrumentation tests API 35, 6 backend tests. Lint: 0 errors / 30 warnings / 3 hints. Исходные данные всех 11 таблиц v2 сохранены после перехода в v4. Подробное подтверждение — FINAL_REPORT.md и соседняя папка verification/product.

## Backend

Инструкция: [backend/README.md](backend/README.md). Server-side OpenAI Responses vision, pairing и Garmin OAuth подготовлены. В APK нет API keys. Публичный backend и аккаунты ещё не созданы: нужен owner email, hosting и credentials. Никакая demo recognition не используется как production fallback.

## Лицензии

Manrope OFL и уведомления сторонних компонентов — LICENSE-Manrope.txt и THIRD_PARTY_NOTICES.md.
